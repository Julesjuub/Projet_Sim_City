#include "maBiblio.h"

int main()///main de notre projet duquel on appel tout les programmes
{
    t_jeu *Jeu = (t_jeu*)malloc(sizeof(t_jeu));///initialisation et allocation de notre structure contenant toutes les donn�es
    clock_t tDebut;
    srand(time(NULL));

    initialisationAllegro();///initialisation allegro

    printf(" \n Initialisation okk ");

    initialisation_struct_Jeu(Jeu);///initialisation de notre structure

    printf("\n pre creation matrice \n");

    Jeu->MAP = Creation_Matrice(); /// On cr�e la matrice contenant toutes les cases du jeu

    tDebut = clock ();
    Jeu->debut = tDebut;///lancement du chronom�tre

    MenuJeu(Jeu); /// Qui va appeler la boucle capitaliste ou la boucle communiste

    return 0;
}END_OF_MAIN()

