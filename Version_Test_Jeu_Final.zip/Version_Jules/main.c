#include "Biblio.h"

int main()
{
    t_jeu *Jeu = (t_jeu*)malloc(sizeof(t_jeu));
    clock_t tDebut;
    srand(time(NULL));

    initialisationAllegro();

    printf(" \n Initialisation okk ");

    initialisation_struct_Jeu(Jeu);

    printf("\n pre creation matrice \n");

    Jeu->MAP = Creation_Matrice(); /// On crée la matrice contenant toutes les cases du jeu

    tDebut = clock ();
    Jeu->debut = tDebut;
    sauvegardePartie(Jeu);

    MenuJeu(Jeu); /// Qui va appeler la boucle capitaliste ou la boucle communiste

    return 0;
}END_OF_MAIN()

